from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import sys
import json
import logging

# Configurar logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Definir modelo simplificado para correção
db = SQLAlchemy()

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='coordenador')
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=True)
    
    def set_senha(self, senha):
        """Método padronizado para definir senha com hash"""
        self.senha_hash = generate_password_hash(senha)
        logger.debug(f"Senha definida para usuário {self.email}")
    
    def verificar_senha(self, senha):
        """Método padronizado para verificar senha"""
        resultado = check_password_hash(self.senha_hash, senha)
        logger.debug(f"Verificação de senha para {self.email}: {'Sucesso' if resultado else 'Falha'}")
        return resultado

class Equipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    descricao = db.Column(db.String(200))

# Criar aplicação Flask para correção
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def corrigir_senhas_coordenadores():
    """Corrige as senhas dos coordenadores para garantir consistência"""
    with app.app_context():
        try:
            # Buscar todos os coordenadores
            coordenadores = Usuario.query.filter_by(nivel_acesso='coordenador').all()
            
            if not coordenadores:
                print('Nenhum coordenador encontrado no banco de dados.')
                return False
            
            print(f'Total de coordenadores encontrados: {len(coordenadores)}')
            
            # Redefinir senhas para cada coordenador
            for c in coordenadores:
                # Determinar senha com base no email
                if 'captacao' in c.email:
                    senha = 'captacao2025'
                elif 'consultoria' in c.email:
                    senha = 'consultoria2025'
                elif 'administrativo' in c.email:
                    senha = 'admin2025'
                else:
                    senha = 'disc2025'  # Senha padrão
                
                # Usar o método padronizado para definir senha
                c.set_senha(senha)
                print(f'Senha redefinida para {c.email}: {senha}')
            
            # Salvar alterações
            db.session.commit()
            print('Senhas de coordenadores corrigidas com sucesso!')
            return True
        except Exception as e:
            print(f'Erro ao corrigir senhas de coordenadores: {e}')
            return False

def verificar_senhas_apos_correcao():
    """Verifica se as senhas foram corrigidas corretamente"""
    with app.app_context():
        try:
            # Verificar todos os usuários
            usuarios = Usuario.query.all()
            
            if not usuarios:
                print('Nenhum usuário encontrado no banco de dados.')
                return False
            
            print(f'Total de usuários encontrados: {len(usuarios)}')
            
            # Testar senhas para cada usuário
            for u in usuarios:
                print(f'ID: {u.id}, Nome: {u.nome}, Email: {u.email}, Nível: {u.nivel_acesso}')
                
                # Determinar senha esperada com base no email e nível
                if u.nivel_acesso == 'admin':
                    senha_esperada = 'disc2025'
                elif 'captacao' in u.email:
                    senha_esperada = 'captacao2025'
                elif 'consultoria' in u.email:
                    senha_esperada = 'consultoria2025'
                elif 'administrativo' in u.email:
                    senha_esperada = 'admin2025'
                else:
                    senha_esperada = 'disc2025'  # Senha padrão
                
                # Testar senha
                resultado = u.verificar_senha(senha_esperada)
                print(f'  Teste de senha "{senha_esperada}": {"SUCESSO" if resultado else "FALHA"}')
                
                # Mostrar hash da senha para análise
                print(f'  Hash da senha: {u.senha_hash}')
                print()
            
            return True
        except Exception as e:
            print(f'Erro ao verificar senhas: {e}')
            return False

if __name__ == "__main__":
    print("\n=== CORRIGINDO SENHAS DE COORDENADORES ===")
    corrigir_senhas_coordenadores()
    
    print("\n=== VERIFICANDO SENHAS APÓS CORREÇÃO ===")
    verificar_senhas_apos_correcao()
