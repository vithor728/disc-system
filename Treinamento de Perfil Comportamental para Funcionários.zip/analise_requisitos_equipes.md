# Análise de Requisitos para Separação por Equipes

## Requisitos Identificados
1. **Separação por Equipes**:
   - Captação Dia
   - Captação Noite
   - Consultoria Dia
   - Consultoria Noite
   - Administrativa

2. **Níveis de Acesso**:
   - **Administrador Geral**: Acesso a todas as equipes e funcionalidades
   - **Coordenadores/Supervisores**: Acesso apenas à sua equipe específica
     - Supervisor da equipe administrativa
     - Gerente da equipe de captação
     - Supervisora da consultoria

3. **Funcionalidades por Nível**:
   - **Administrador Geral**:
     - Visualizar todas as equipes
     - Criar/gerenciar usuários e seus acessos
     - Acessar todos os relatórios e estatísticas
     - Exportar dados de todas as equipes
   
   - **Coordenadores/Supervisores**:
     - Visualizar apenas colaboradores da sua equipe
     - Acessar relatórios e estatísticas da sua equipe
     - Exportar dados apenas da sua equipe

## Alterações Necessárias no Modelo de Dados

1. **Tabela de Equipes**:
   - ID
   - Nome da Equipe
   - Descrição (opcional)

2. **Atualização na Tabela de Colaboradores**:
   - Adicionar campo para ID da Equipe (chave estrangeira)

3. **Tabela de Usuários do Sistema**:
   - ID
   - Nome
   - Email
   - Senha (hash)
   - Nível de Acesso (admin, coordenador)
   - ID da Equipe (para coordenadores, NULL para admin)

## Alterações na Interface

1. **Tela de Login**:
   - Manter a mesma estrutura, mas com autenticação baseada na nova tabela de usuários

2. **Painel do Administrador**:
   - Adicionar seção para gerenciamento de usuários e equipes
   - Adicionar filtro por equipe nos relatórios e estatísticas
   - Manter todas as funcionalidades existentes

3. **Painel do Coordenador**:
   - Similar ao painel atual, mas com dados filtrados apenas para sua equipe
   - Remover opções de gerenciamento de usuários e equipes

4. **Questionário**:
   - Adicionar campo para seleção da equipe no formulário de identificação

## Considerações de Segurança

1. **Autenticação**:
   - Implementar sistema de login seguro
   - Armazenar senhas com hash e salt
   - Implementar controle de sessão

2. **Autorização**:
   - Verificar permissões em todas as rotas
   - Filtrar dados baseado no nível de acesso e equipe do usuário
   - Prevenir acesso não autorizado via manipulação de URLs

## Plano de Implementação

1. Atualizar o esquema do banco de dados
2. Implementar o sistema de autenticação e autorização
3. Atualizar as rotas para filtrar dados por equipe
4. Criar interface para gerenciamento de usuários e equipes
5. Atualizar o questionário para incluir seleção de equipe
6. Testar todas as funcionalidades com diferentes níveis de acesso
7. Implantar a versão atualizada
