# Guia de Implantação do Sistema DISC no Render.com

Este guia detalha o processo de implantação do Sistema DISC no Render.com, garantindo persistência permanente dos dados através do PostgreSQL.

## Índice

1. [Pré-requisitos](#pré-requisitos)
2. [Preparação do Código](#preparação-do-código)
3. [Criação da Conta no Render.com](#criação-da-conta-no-rendercom)
4. [Configuração do Banco de Dados PostgreSQL](#configuração-do-banco-de-dados-postgresql)
5. [Implantação do Serviço Web](#implantação-do-serviço-web)
6. [Configuração das Variáveis de Ambiente](#configuração-das-variáveis-de-ambiente)
7. [Migração de Dados (Opcional)](#migração-de-dados-opcional)
8. [Verificação e Testes](#verificação-e-testes)
9. [Manutenção e Atualizações](#manutenção-e-atualizações)
10. [Solução de Problemas](#solução-de-problemas)

## Pré-requisitos

- Conta GitHub (para hospedar o código)
- Conta no Render.com (gratuita para começar)
- Código do Sistema DISC adaptado para PostgreSQL (já fornecido)

## Preparação do Código

1. **Crie um repositório no GitHub**:
   - Acesse [GitHub](https://github.com) e crie um novo repositório
   - Nome sugerido: `disc-system`

2. **Prepare o código para upload**:
   - Certifique-se de que o arquivo `src/main_postgres.py` está renomeado para `src/main.py`
   - Verifique se o arquivo `requirements.txt` contém todas as dependências necessárias
   - Certifique-se de que o arquivo `.gitignore` inclui `.env` e outros arquivos sensíveis

3. **Faça upload do código para o GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Versão inicial do Sistema DISC"
   git branch -M main
   git remote add origin https://github.com/seu-usuario/disc-system.git
   git push -u origin main
   ```

## Criação da Conta no Render.com

1. Acesse [Render.com](https://render.com) e crie uma conta gratuita
2. Confirme seu e-mail e faça login na plataforma

## Configuração do Banco de Dados PostgreSQL

1. No painel do Render.com, clique em "New +" e selecione "PostgreSQL"
2. Configure o banco de dados:
   - **Nome**: `disc-db`
   - **Plano**: Free (gratuito)
   - **Região**: Escolha a mais próxima da sua localização
   - **Nome do Banco de Dados**: `disc_app`
   - **Usuário**: Deixe o padrão gerado automaticamente
   - **Senha**: Deixe o Render gerar uma senha segura

3. Clique em "Create Database" e aguarde a criação (pode levar alguns minutos)

4. Após a criação, anote as seguintes informações:
   - **Internal Database URL**: Será usado como `DATABASE_URL` na configuração do serviço web
   - **Username**: Nome de usuário gerado
   - **Password**: Senha gerada
   - **Database**: Nome do banco de dados (`disc_app`)

## Implantação do Serviço Web

1. No painel do Render.com, clique em "New +" e selecione "Web Service"

2. Conecte sua conta GitHub e selecione o repositório `disc-system`

3. Configure o serviço web:
   - **Nome**: `disc-system`
   - **Ambiente**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn "src.main:app" --bind 0.0.0.0:$PORT`
   - **Plano**: Free (gratuito)
   - **Região**: Escolha a mesma região do banco de dados

## Configuração das Variáveis de Ambiente

1. Na página de configuração do serviço web, role até a seção "Environment Variables"

2. Adicione as seguintes variáveis:
   - **DATABASE_URL**: Cole o valor do "Internal Database URL" do seu banco PostgreSQL
   - **SECRET_KEY**: Gere uma chave secreta forte (pode usar [este gerador](https://randomkeygen.com/))
   - **FLASK_ENV**: `production`

3. Clique em "Save Changes" e aguarde a implantação (pode levar alguns minutos)

## Migração de Dados (Opcional)

Se você já possui dados no sistema atual e deseja migrá-los para o novo ambiente:

1. **Exportação dos dados atuais**:
   - Acesse o painel administrativo do sistema atual
   - Use a função "Exportar CSV" para cada tipo de dado (colaboradores, equipes)

2. **Importação no novo sistema**:
   - Após o sistema estar online no Render.com, faça login como administrador
   - Recrie manualmente as equipes
   - Para colaboradores, você pode criar um script de importação ou inserir manualmente os mais importantes

## Verificação e Testes

Após a implantação, realize os seguintes testes:

1. **Acesso ao sistema**:
   - Acesse a URL fornecida pelo Render.com (formato: `https://disc-system.onrender.com`)
   - Verifique se a página inicial carrega corretamente

2. **Login de administrador**:
   - Use as credenciais padrão:
     - Usuário: `admin`
     - Senha: `disc2025`
   - Verifique se consegue acessar o painel administrativo

3. **Teste de persistência**:
   - Preencha um questionário de teste
   - Verifique se os dados aparecem no painel administrativo
   - Aguarde 30 minutos e verifique novamente se os dados ainda estão disponíveis
   - Reinicie o serviço no painel do Render.com e verifique se os dados persistem

## Manutenção e Atualizações

Para atualizar o sistema no futuro:

1. **Atualizações de código**:
   - Faça as alterações necessárias no código localmente
   - Envie as alterações para o GitHub:
     ```bash
     git add .
     git commit -m "Descrição das alterações"
     git push origin main
     ```
   - O Render.com detectará automaticamente as alterações e reimplantará o serviço

2. **Backups do banco de dados**:
   - O Render.com realiza backups automáticos diários do banco de dados
   - Você também pode criar backups manuais no painel do banco de dados

## Solução de Problemas

### O sistema não está salvando os dados

1. Verifique se a variável `DATABASE_URL` está configurada corretamente
2. Verifique os logs do serviço no painel do Render.com para identificar erros
3. Teste a conexão com o banco de dados usando a rota `/status_db`

### Erro ao acessar o sistema

1. Verifique se o serviço está em execução no painel do Render.com
2. Verifique os logs para identificar erros de inicialização
3. Tente reiniciar o serviço

### Desempenho lento

1. No plano gratuito, o serviço pode "adormecer" após períodos de inatividade
2. O primeiro acesso após um período de inatividade pode ser mais lento
3. Para evitar isso, considere atualizar para um plano pago

---

## Contato e Suporte

Se precisar de ajuda adicional com a implantação ou tiver dúvidas sobre o sistema, entre em contato com o suporte técnico.

---

*Este guia foi criado para facilitar a implantação do Sistema DISC no Render.com, garantindo persistência permanente dos dados através do PostgreSQL.*
