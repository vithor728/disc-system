// Funções JavaScript para o site DISC
document.addEventListener('DOMContentLoaded', function() {
    // Menu mobile
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
    
    // Fechar menu ao clicar em um item
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
    
    // Animações de entrada
    const fadeElements = document.querySelectorAll('.fade-in');
    
    if (fadeElements.length > 0) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = 1;
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        });
        
        fadeElements.forEach(element => {
            element.style.opacity = 0;
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            observer.observe(element);
        });
    }
    
    // Questionário DISC (se estiver na página do questionário)
    setupQuestionnaireIfPresent();
});

function setupQuestionnaireIfPresent() {
    const discForm = document.getElementById('disc-form');
    
    if (!discForm) return;
    
    // Limitar seleções por grupo
    const groups = document.querySelectorAll('.question-group');
    groups.forEach(group => {
        const checkboxes = group.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const checkedCount = group.querySelectorAll('input[type="checkbox"]:checked').length;
                if (checkedCount > 2) {
                    checkbox.checked = false;
                    alert('Você só pode selecionar DUAS opções por grupo.');
                }
            });
        });
    });
    
    // Botão de cálculo
    const calculateButton = document.querySelector('button[onclick="calculateResults()"]');
    if (calculateButton) {
        calculateButton.removeAttribute('onclick');
        calculateButton.addEventListener('click', calculateResults);
    }
}

function calculateResults() {
    const scores = { D: 0, I: 0, S: 0, C: 0 };
    const totalGroups = 10;
    let allGroupsValid = true;
    const errorMessageDiv = document.getElementById('error-message');
    errorMessageDiv.textContent = ''; // Limpa mensagens de erro anteriores

    for (let i = 1; i <= totalGroups; i++) {
        const groupCheckboxes = document.querySelectorAll(`input[name="group${i}"]:checked`);
        if (groupCheckboxes.length !== 2) {
            allGroupsValid = false;
            errorMessageDiv.textContent = `Erro: Por favor, selecione exatamente DUAS opções no Grupo ${i}.`;
            document.getElementById('results').style.display = 'none'; // Esconde resultados se houver erro
            // Foca no grupo com erro para facilitar a correção
            document.querySelector(`.question-group[data-group="${i}"]`).scrollIntoView({ behavior: 'smooth', block: 'center' });
            break; // Para no primeiro erro encontrado
        }
        groupCheckboxes.forEach(checkbox => {
            scores[checkbox.value]++;
        });
    }

    if (allGroupsValid) {
        document.getElementById('score-d').textContent = scores.D;
        document.getElementById('score-i').textContent = scores.I;
        document.getElementById('score-s').textContent = scores.S;
        document.getElementById('score-c').textContent = scores.C;

        // Encontrar perfil(s) predominante(s)
        let maxScore = 0;
        for (const profile in scores) {
            if (scores[profile] > maxScore) {
                maxScore = scores[profile];
            }
        }
        const dominantProfiles = [];
        for (const profile in scores) {
            if (scores[profile] === maxScore) {
                dominantProfiles.push(profile);
            }
        }
        
        const dominantProfilesText = dominantProfiles.join(', ');
        document.getElementById('dominant-profile').textContent = dominantProfilesText;
        
        // Gerar descrição do perfil
        generateProfileDescription(dominantProfiles);

        // Exibir resultados e rolar para eles
        const resultsDiv = document.getElementById('results');
        resultsDiv.style.display = 'block';
        resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
}

function generateProfileDescription(dominantProfiles) {
    const profileDetailsDiv = document.getElementById('profile-details');
    profileDetailsDiv.innerHTML = ''; // Limpa conteúdo anterior
    
    // Descrições dos perfis
    const profileDescriptions = {
        D: {
            title: "Dominância (Executor)",
            characteristics: [
                "Direto, assertivo e focado em resultados",
                "Forte senso de urgência e orientação para ação",
                "Alta autoconfiança e competitividade",
                "Tomada de decisão rápida e objetiva",
                "Prospera em ambientes dinâmicos e desafiadores"
            ],
            strengths: [
                "Foco em resultados",
                "Decisões rápidas",
                "Liderança natural",
                "Resiliência sob pressão",
                "Iniciativa e proatividade"
            ],
            challenges: [
                "Pode parecer impaciente ou insensível",
                "Dificuldade em ouvir outras opiniões",
                "Resistência a regras e procedimentos",
                "Pode negligenciar detalhes importantes"
            ]
        },
        I: {
            title: "Influência (Comunicador)",
            characteristics: [
                "Extrovertido, sociável e falante",
                "Otimista e entusiasmado",
                "Persuasivo e naturalmente carismático",
                "Comunicação expressiva e envolvente",
                "Prospera em ambientes sociais e colaborativos"
            ],
            strengths: [
                "Excelente comunicação",
                "Construção de relacionamentos",
                "Entusiasmo contagiante",
                "Criatividade e novas ideias",
                "Adaptabilidade social"
            ],
            challenges: [
                "Pode falar mais do que ouvir",
                "Dificuldade com prazos e detalhes",
                "Tendência a evitar conflitos",
                "Pode ser desorganizado ou disperso"
            ]
        },
        S: {
            title: "Estabilidade (Planejador)",
            characteristics: [
                "Paciente, tranquilo e metódico",
                "Excelente ouvinte e empático",
                "Leal, confiável e consistente",
                "Comunicação calma e ponderada",
                "Prospera em ambientes estáveis e previsíveis"
            ],
            strengths: [
                "Lealdade e confiabilidade",
                "Excelente escuta e empatia",
                "Trabalho em equipe",
                "Consistência e paciência",
                "Habilidade para acalmar tensões"
            ],
            challenges: [
                "Resistência a mudanças",
                "Dificuldade em expressar opiniões",
                "Pode evitar riscos e inovações",
                "Tendência a ser muito acomodado"
            ]
        },
        C: {
            title: "Conformidade (Analista)",
            characteristics: [
                "Analítico, lógico e sistemático",
                "Preciso, detalhista e organizado",
                "Valoriza qualidade e exatidão",
                "Comunicação formal, factual e baseada em evidências",
                "Prospera em ambientes estruturados e com regras claras"
            ],
            strengths: [
                "Atenção aos detalhes",
                "Pensamento analítico",
                "Organização e planejamento",
                "Disciplina e procedimentos",
                "Identificação de riscos"
            ],
            challenges: [
                "Perfeccionismo",
                "Lentidão nas decisões",
                "Resistência a ideias novas",
                "Dificuldade com ambiguidades"
            ]
        },
        // Combinações comuns
        "D,I": {
            title: "Dominância + Influência (Empreendedor)",
            characteristics: [
                "Assertivo, focado em resultados e persuasivo",
                "Líder nato com excelente comunicação",
                "Gosta de correr riscos calculados",
                "Combina ação direta com habilidades sociais",
                "Orientado para resultados, mas com abordagem envolvente"
            ]
        },
        "D,C": {
            title: "Dominância + Conformidade (Inovador)",
            characteristics: [
                "Questionador e analítico",
                "Vê oportunidades onde outros não veem",
                "Busca soluções lógicas e é cauteloso em suas análises",
                "Combina assertividade com precisão",
                "Orientado para resultados, mas com atenção aos detalhes"
            ]
        },
        "I,S": {
            title: "Influência + Estabilidade (Aconselhador)",
            characteristics: [
                "Excelente relacionamento interpessoal",
                "Expressivo e bom ouvinte",
                "Observador atento às dinâmicas de grupo",
                "Combina entusiasmo com paciência",
                "Habilidade para motivar e apoiar pessoas"
            ]
        },
        "S,C": {
            title: "Estabilidade + Conformidade (Especialista)",
            characteristics: [
                "Grande capacidade de se aprofundar em um assunto",
                "Torna-se perito e referência técnica em suas áreas",
                "Metódico, preciso e confiável",
                "Combina paciência com atenção aos detalhes",
                "Valoriza qualidade e consistência"
            ]
        },
        "I,C": {
            title: "Influência + Conformidade (Integrador)",
            characteristics: [
                "Envolvente e focado",
                "Valoriza necessidades pessoais e do ambiente",
                "Combina habilidades sociais com precisão",
                "Comunica ideias complexas de forma acessível",
                "Equilibra entusiasmo com análise"
            ]
        },
        "D,S": {
            title: "Dominância + Estabilidade (Organizador)",
            characteristics: [
                "Excelente em estruturar processos",
                "Fiel e valoriza normas",
                "Combina assertividade com paciência",
                "Orientado para resultados, mas de forma consistente",
                "Liderança estável e determinada"
            ]
        }
    };
    
    if (dominantProfiles.length === 1) {
        // Perfil único
        const profile = dominantProfiles[0];
        const profileInfo = profileDescriptions[profile];
        
        const profileCard = document.createElement('div');
        profileCard.className = `profile-card profile-${profile.toLowerCase()}`;
        
        const titleDiv = document.createElement('div');
        titleDiv.className = 'profile-title';
        
        const iconSpan = document.createElement('span');
        iconSpan.className = `profile-icon icon-${profile.toLowerCase()}`;
        iconSpan.textContent = profile;
        
        const titleH4 = document.createElement('h4');
        titleH4.textContent = profileInfo.title;
        
        titleDiv.appendChild(iconSpan);
        titleDiv.appendChild(titleH4);
        profileCard.appendChild(titleDiv);
        
        // Características
        const characteristicsH5 = document.createElement('h5');
        characteristicsH5.textContent = 'Características Principais:';
        profileCard.appendChild(characteristicsH5);
        
        const characteristicsList = document.createElement('ul');
        characteristicsList.className = 'characteristics-list';
        profileInfo.characteristics.forEach(characteristic => {
            const li = document.createElement('li');
            li.textContent = characteristic;
            characteristicsList.appendChild(li);
        });
        profileCard.appendChild(characteristicsList);
        
        // Pontos Fortes
        const strengthsH5 = document.createElement('h5');
        strengthsH5.textContent = 'Pontos Fortes:';
        profileCard.appendChild(strengthsH5);
        
        const strengthsList = document.createElement('ul');
        strengthsList.className = 'characteristics-list';
        profileInfo.strengths.forEach(strength => {
            const li = document.createElement('li');
            li.textContent = strength;
            strengthsList.appendChild(li);
        });
        profileCard.appendChild(strengthsList);
        
        // Desafios
        const challengesH5 = document.createElement('h5');
        challengesH5.textContent = 'Pontos a Desenvolver:';
        profileCard.appendChild(challengesH5);
        
        const challengesList = document.createElement('ul');
        challengesList.className = 'characteristics-list';
        profileInfo.challenges.forEach(challenge => {
            const li = document.createElement('li');
            li.textContent = challenge;
            challengesList.appendChild(li);
        });
        profileCard.appendChild(challengesList);
        
        profileDetailsDiv.appendChild(profileCard);
    } else if (dominantProfiles.length === 2) {
        // Perfil combinado de 2
        const combinationKey = dominantProfiles.join(',');
        const reverseCombinationKey = dominantProfiles[1] + ',' + dominantProfiles[0];
        
        // Verifica se temos uma descrição específica para esta combinação
        const profileInfo = profileDescriptions[combinationKey] || profileDescriptions[reverseCombinationKey];
        
        if (profileInfo) {
            const profileCard = document.createElement('div');
            profileCard.className = 'profile-card profile-combined';
            
            const titleDiv = document.createElement('div');
            titleDiv.className = 'profile-title';
            
            dominantProfiles.forEach(profile => {
                const iconSpan = document.createElement('span');
                iconSpan.className = `profile-icon icon-${profile.toLowerCase()}`;
                iconSpan.textContent = profile;
                titleDiv.appendChild(iconSpan);
            });
            
            const titleH4 = document.createElement('h4');
            titleH4.textContent = profileInfo.title;
            titleDiv.appendChild(titleH4);
            
            profileCard.appendChild(titleDiv);
            
            // Características
            const characteristicsH5 = document.createElement('h5');
            characteristicsH5.textContent = 'Características desta Combinação:';
            profileCard.appendChild(characteristicsH5);
            
            const characteristicsList = document.createElement('ul');
            characteristicsList.className = 'characteristics-list';
            profileInfo.characteristics.forEach(characteristic => {
                const li = document.createElement('li');
                li.textContent = characteristic;
                characteristicsList.appendChild(li);
            });
            profileCard.appendChild(characteristicsList);
            
            profileDetailsDiv.appendChild(profileCard);
        } else {
            // Se não temos descrição específica, mostramos uma mensagem genérica
            const combinationMessage = document.createElement('p');
            combinationMessage.textContent = `Você apresenta uma combinação interessante dos perfis ${dominantProfiles.join(', ')}. Esta combinação traz uma riqueza de características que se complementam. Consulte o material de treinamento para mais detalhes sobre combinações de perfis.`;
            profileDetailsDiv.appendChild(combinationMessage);
        }
    } else {
        // 3 ou mais perfis empatados (raro)
        const combinationMessage = document.createElement('p');
        combinationMessage.textContent = `Você apresenta um equilíbrio entre os perfis ${dominantProfiles.join(', ')}. Esta distribuição equilibrada sugere versatilidade comportamental. Consulte o material de treinamento para mais detalhes sobre como estes perfis interagem.`;
        profileDetailsDiv.appendChild(combinationMessage);
    }
}
