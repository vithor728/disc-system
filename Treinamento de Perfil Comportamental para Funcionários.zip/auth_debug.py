from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, g, current_app
import os
import sys
import json
import datetime
import logging
from pathlib import Path
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# Configurar logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Definir modelo simplificado para diagnóstico
db = SQLAlchemy()

class Equipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    descricao = db.Column(db.String(200))
    
    colaboradores = db.relationship('Colaborador', backref='equipe', lazy=True)
    usuarios = db.relationship('Usuario', backref='equipe', lazy=True)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='coordenador')
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=True)
    
    def set_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)
        logger.debug(f"Senha definida para usuário {self.email}")
    
    def verificar_senha(self, senha):
        resultado = check_password_hash(self.senha_hash, senha)
        logger.debug(f"Verificação de senha para {self.email}: {'Sucesso' if resultado else 'Falha'}")
        return resultado
    
    def is_admin(self):
        return self.nivel_acesso == 'admin'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'nivel_acesso': self.nivel_acesso,
            'equipe_id': self.equipe_id
        }

class Colaborador(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    cargo = db.Column(db.String(100))
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=False)
    data_preenchimento = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    pontuacao_d = db.Column(db.Integer, default=0)
    pontuacao_i = db.Column(db.Integer, default=0)
    pontuacao_s = db.Column(db.Integer, default=0)
    pontuacao_c = db.Column(db.Integer, default=0)
    
    perfil_predominante = db.Column(db.String(1))
    perfil_secundario = db.Column(db.String(1))
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'cargo': self.cargo,
            'equipe_id': self.equipe_id,
            'data_preenchimento': self.data_preenchimento.isoformat() if self.data_preenchimento else None,
            'pontuacao': {
                'D': self.pontuacao_d,
                'I': self.pontuacao_i,
                'S': self.pontuacao_s,
                'C': self.pontuacao_c
            },
            'perfil_predominante': self.perfil_predominante,
            'perfil_secundario': self.perfil_secundario
        }

# Funções de autenticação
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        logger.debug("Verificando autenticação")
        if 'usuario_id' not in session:
            logger.debug("Usuário não autenticado, redirecionando para login")
            flash('Por favor, faça login para acessar esta página.', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        logger.debug("Verificando permissão de administrador")
        if 'usuario_id' not in session:
            logger.debug("Usuário não autenticado, redirecionando para login")
            flash('Por favor, faça login para acessar esta página.', 'warning')
            return redirect(url_for('login', next=request.url))
        
        if not g.usuario.is_admin():
            logger.debug(f"Acesso negado: usuário {g.usuario.email} não é administrador")
            flash('Acesso negado. Você não tem permissão para acessar esta página.', 'danger')
            return redirect(url_for('admin'))
        
        return f(*args, **kwargs)
    return decorated_function

def pode_acessar_equipe(equipe_id):
    if g.usuario.is_admin():
        return True
    return g.usuario.equipe_id == equipe_id

def pode_acessar_colaborador(colaborador):
    if g.usuario.is_admin():
        return True
    return g.usuario.equipe_id == colaborador.equipe_id

def init_auth(app, db):
    @app.before_request
    def carregar_usuario_logado():
        usuario_id = session.get('usuario_id')
        if usuario_id is None:
            g.usuario = None
        else:
            try:
                g.usuario = Usuario.query.get(usuario_id)
                logger.debug(f"Usuário carregado: {g.usuario.email if g.usuario else 'Nenhum'}")
            except Exception as e:
                logger.error(f"Erro ao carregar usuário: {e}")
                g.usuario = None

def criar_usuario_admin_inicial(db):
    admin = Usuario.query.filter_by(email='admin').first()
    if not admin:
        admin = Usuario(
            nome="Administrador",
            email="admin",
            nivel_acesso="admin"
        )
        admin.set_senha("disc2025")
        db.session.add(admin)
        db.session.commit()
        logger.info("Usuário administrador inicial criado")
    else:
        logger.info("Usuário administrador já existe")

def criar_equipes_iniciais(db):
    equipes = [
        {'nome': 'Captação Dia', 'descricao': 'Equipe de captação - turno diurno'},
        {'nome': 'Captação Noite', 'descricao': 'Equipe de captação - turno noturno'},
        {'nome': 'Consultoria Dia', 'descricao': 'Equipe de consultoria - turno diurno'},
        {'nome': 'Consultoria Noite', 'descricao': 'Equipe de consultoria - turno noturno'},
        {'nome': 'Administrativa', 'descricao': 'Equipe administrativa'}
    ]
    
    for e in equipes:
        if not Equipe.query.filter_by(nome=e['nome']).first():
            equipe = Equipe(nome=e['nome'], descricao=e['descricao'])
            db.session.add(equipe)
    
    db.session.commit()
    logger.info("Equipes iniciais criadas")

def criar_coordenadores_iniciais(db):
    coordenadores = [
        {
            'nome': 'Gerente de Captação',
            'email': 'captacao@exemplo.com',
            'senha': 'captacao2025',
            'equipe_nome': 'Captação Dia'
        },
        {
            'nome': 'Supervisora de Consultoria',
            'email': 'consultoria@exemplo.com',
            'senha': 'consultoria2025',
            'equipe_nome': 'Consultoria Dia'
        },
        {
            'nome': 'Supervisor Administrativo',
            'email': 'administrativo@exemplo.com',
            'senha': 'admin2025',
            'equipe_nome': 'Administrativa'
        }
    ]
    
    for c in coordenadores:
        if not Usuario.query.filter_by(email=c['email']).first():
            equipe = Equipe.query.filter_by(nome=c['equipe_nome']).first()
            if equipe:
                coordenador = Usuario(
                    nome=c['nome'],
                    email=c['email'],
                    nivel_acesso='coordenador',
                    equipe_id=equipe.id
                )
                coordenador.set_senha(c['senha'])
                db.session.add(coordenador)
    
    db.session.commit()
    logger.info("Coordenadores iniciais criados")

# Função de diagnóstico para verificar o estado do banco
def diagnosticar_banco():
    try:
        # Verificar tabelas
        tabelas = db.engine.table_names()
        logger.info(f"Tabelas no banco: {tabelas}")
        
        # Verificar usuários
        usuarios = Usuario.query.all()
        logger.info(f"Total de usuários: {len(usuarios)}")
        for u in usuarios:
            logger.info(f"Usuário: {u.email}, Nível: {u.nivel_acesso}, Senha hash: {u.senha_hash[:20]}...")
        
        # Verificar equipes
        equipes = Equipe.query.all()
        logger.info(f"Total de equipes: {len(equipes)}")
        for e in equipes:
            logger.info(f"Equipe: {e.nome}")
        
        return {
            'tabelas': tabelas,
            'usuarios': [u.to_dict() for u in usuarios],
            'equipes': [{'id': e.id, 'nome': e.nome} for e in equipes]
        }
    except Exception as e:
        logger.error(f"Erro ao diagnosticar banco: {e}")
        return {'erro': str(e)}

# Função para testar autenticação
def testar_autenticacao(email, senha):
    try:
        usuario = Usuario.query.filter_by(email=email).first()
        if not usuario:
            logger.warning(f"Usuário não encontrado: {email}")
            return False, "Usuário não encontrado"
        
        logger.debug(f"Testando senha para {email}")
        if usuario.verificar_senha(senha):
            logger.info(f"Autenticação bem-sucedida para {email}")
            return True, "Autenticação bem-sucedida"
        else:
            logger.warning(f"Senha incorreta para {email}")
            return False, "Senha incorreta"
    except Exception as e:
        logger.error(f"Erro ao testar autenticação: {e}")
        return False, f"Erro: {str(e)}"
