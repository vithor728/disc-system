from functools import wraps
from flask import session, redirect, url_for, flash, request, g
from src.models import Usuario, Equipe

def init_auth(app, db):
    @app.before_request
    def load_usuario_logado():
        usuario_id = session.get('usuario_id')
        if usuario_id is None:
            g.usuario = None
        else:
            g.usuario = Usuario.query.get(usuario_id)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            flash('Por favor, faça login para acessar esta página.', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:
            flash('Por favor, faça login para acessar esta página.', 'warning')
            return redirect(url_for('login', next=request.url))
        
        usuario = Usuario.query.get(session['usuario_id'])
        if not usuario or not usuario.is_admin():
            flash('Você não tem permissão para acessar esta página.', 'danger')
            return redirect(url_for('index'))
        
        return f(*args, **kwargs)
    return decorated_function

def pode_acessar_equipe(equipe_id):
    """Verifica se o usuário logado pode acessar uma determinada equipe"""
    if 'usuario_id' not in session:
        return False
    
    usuario = Usuario.query.get(session['usuario_id'])
    if not usuario:
        return False
    
    # Administradores podem acessar qualquer equipe
    if usuario.is_admin():
        return True
    
    # Coordenadores só podem acessar sua própria equipe
    return usuario.equipe_id == equipe_id

def pode_acessar_colaborador(colaborador):
    """Verifica se o usuário logado pode acessar um determinado colaborador"""
    if 'usuario_id' not in session:
        return False
    
    usuario = Usuario.query.get(session['usuario_id'])
    if not usuario:
        return False
    
    # Administradores podem acessar qualquer colaborador
    if usuario.is_admin():
        return True
    
    # Coordenadores só podem acessar colaboradores da sua equipe
    return usuario.equipe_id == colaborador.equipe_id

def criar_usuario_admin_inicial(db):
    """Cria um usuário administrador inicial se não existir nenhum"""
    if Usuario.query.filter_by(nivel_acesso='admin').first() is None:
        admin = Usuario(
            nome='Administrador',
            email='admin@exemplo.com',
            nivel_acesso='admin'
        )
        admin.set_senha('disc2025')
        db.session.add(admin)
        db.session.commit()
        return True
    return False

def criar_equipes_iniciais(db):
    """Cria as equipes iniciais se não existirem"""
    equipes = [
        {'nome': 'Captação Dia', 'descricao': 'Equipe de captação - turno diurno'},
        {'nome': 'Captação Noite', 'descricao': 'Equipe de captação - turno noturno'},
        {'nome': 'Consultoria Dia', 'descricao': 'Equipe de consultoria - turno diurno'},
        {'nome': 'Consultoria Noite', 'descricao': 'Equipe de consultoria - turno noturno'},
        {'nome': 'Administrativa', 'descricao': 'Equipe administrativa'}
    ]
    
    equipes_criadas = 0
    for e in equipes:
        if not Equipe.query.filter_by(nome=e['nome']).first():
            equipe = Equipe(nome=e['nome'], descricao=e['descricao'])
            db.session.add(equipe)
            equipes_criadas += 1
    
    if equipes_criadas > 0:
        db.session.commit()
        return True
    return False

def criar_coordenadores_iniciais(db):
    """Cria os coordenadores iniciais se não existirem"""
    coordenadores = [
        {
            'nome': 'Gerente de Captação',
            'email': 'captacao@exemplo.com',
            'senha': 'captacao2025',
            'equipe_nome': 'Captação Dia'  # Este coordenador terá acesso a Captação Dia
        },
        {
            'nome': 'Supervisora de Consultoria',
            'email': 'consultoria@exemplo.com',
            'senha': 'consultoria2025',
            'equipe_nome': 'Consultoria Dia'  # Este coordenador terá acesso a Consultoria Dia
        },
        {
            'nome': 'Supervisor Administrativo',
            'email': 'administrativo@exemplo.com',
            'senha': 'admin2025',
            'equipe_nome': 'Administrativa'  # Este coordenador terá acesso a Administrativa
        }
    ]
    
    coordenadores_criados = 0
    for c in coordenadores:
        if not Usuario.query.filter_by(email=c['email']).first():
            equipe = Equipe.query.filter_by(nome=c['equipe_nome']).first()
            if equipe:
                coordenador = Usuario(
                    nome=c['nome'],
                    email=c['email'],
                    nivel_acesso='coordenador',
                    equipe_id=equipe.id
                )
                coordenador.set_senha(c['senha'])
                db.session.add(coordenador)
                coordenadores_criados += 1
    
    if coordenadores_criados > 0:
        db.session.commit()
        return True
    return False
