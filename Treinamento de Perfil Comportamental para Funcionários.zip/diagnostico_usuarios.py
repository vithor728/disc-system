from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
import os
import sys
import json

# Definir modelo simplificado para diagnóstico
db = SQLAlchemy()

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='admin')
    equipe_id = db.Column(db.Integer, nullable=True)

# Criar aplicação Flask para diagnóstico
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def diagnosticar_usuarios():
    """Diagnostica os usuários existentes no banco de dados"""
    with app.app_context():
        try:
            # Verificar se a tabela existe
            usuarios = Usuario.query.all()
            
            if not usuarios:
                print("Nenhum usuário encontrado no banco de dados.")
                return False
            
            print(f"Total de usuários encontrados: {len(usuarios)}")
            
            # Listar todos os usuários
            for u in usuarios:
                print(f"ID: {u.id}, Nome: {u.nome}, Email: {u.email}, Nível: {u.nivel_acesso}, Equipe ID: {u.equipe_id}")
            
            return True
        except Exception as e:
            print(f"Erro ao diagnosticar usuários: {e}")
            return False

def criar_admin_garantido():
    """Cria um usuário administrador garantido com múltiplas opções de login"""
    with app.app_context():
        try:
            # Criar ou atualizar usuário admin principal
            admin_email = "victor.lima@gavresorts.com.br"
            admin = Usuario.query.filter_by(email=admin_email).first()
            
            if admin:
                admin.nome = "Victor Lima"
                admin.senha_hash = generate_password_hash("disc2025")
                admin.nivel_acesso = "admin"
                print(f"Administrador atualizado: {admin_email}")
            else:
                admin = Usuario(
                    nome="Victor Lima",
                    email=admin_email,
                    senha_hash=generate_password_hash("disc2025"),
                    nivel_acesso="admin"
                )
                db.session.add(admin)
                print(f"Administrador criado: {admin_email}")
            
            # Criar admin alternativo com login simplificado
            admin_simples = Usuario.query.filter_by(email="admin").first()
            if not admin_simples:
                admin_simples = Usuario(
                    nome="Administrador",
                    email="admin",
                    senha_hash=generate_password_hash("disc2025"),
                    nivel_acesso="admin"
                )
                db.session.add(admin_simples)
                print("Administrador alternativo criado: admin")
            
            # Criar admin com email padrão
            admin_padrao = Usuario.query.filter_by(email="admin@exemplo.com").first()
            if not admin_padrao:
                admin_padrao = Usuario(
                    nome="Administrador Padrão",
                    email="admin@exemplo.com",
                    senha_hash=generate_password_hash("disc2025"),
                    nivel_acesso="admin"
                )
                db.session.add(admin_padrao)
                print("Administrador padrão criado: admin@exemplo.com")
            
            db.session.commit()
            print("Operação concluída com sucesso!")
            return True
        except Exception as e:
            print(f"Erro ao criar administrador garantido: {e}")
            return False

if __name__ == "__main__":
    print("\n=== DIAGNÓSTICO DE USUÁRIOS ===")
    diagnosticar_usuarios()
    
    print("\n=== CRIANDO ADMINISTRADORES GARANTIDOS ===")
    criar_admin_garantido()
    
    print("\n=== DIAGNÓSTICO FINAL ===")
    diagnosticar_usuarios()
    
    print("\n=== CREDENCIAIS DE ACESSO ===")
    print("Opção 1:")
    print("  Email/Usuário: victor.lima@gavresorts.com.br")
    print("  Senha: disc2025")
    print("\nOpção 2:")
    print("  Email/Usuário: admin")
    print("  Senha: disc2025")
    print("\nOpção 3:")
    print("  Email/Usuário: admin@exemplo.com")
    print("  Senha: disc2025")
