# Estrutura da Apresentação DISC

**Objetivo:** Apresentar a metodologia DISC de forma clara, didática e visualmente atraente, cobrindo os conceitos principais, perfis, combinações, aplicações práticas e feedback personalizado.

**Público:** Colaboradores e gestores interessados em autoconhecimento e melhoria das relações interpessoais no trabalho.

**Base:** Conteúdo do arquivo `/home/ubuntu/treinamento_disc_completo.md`.

## Roteiro dos Slides:

1.  **Slide 1: Capa**
    *   Título: Desvendando Perfis Comportamentais: Uma Introdução à Metodologia DISC
    *   Subtítulo: Compreendendo a si mesmo e aos outros para melhores resultados.
    *   Imagem: Conceitual de equipe diversa interagindo ou gráfico abstrato representando conexões.

2.  **Slide 2: Por Que Falar de Comportamento?**
    *   Importância de entender o comportamento no ambiente de trabalho (comunicação, colaboração, liderança, resultados).
    *   Introdução ao DISC como ferramenta de autoconhecimento e compreensão mútua.
    *   Objetivo do treinamento: Fornecer um framework, não rotular.

3.  **Slide 3: O Que é DISC?**
    *   Origem: Dr. William Moulton Marston ("Emoções das Pessoas Normais").
    *   Acrônimo: **D**ominância, **I**nfluência, **E**stabilidade (Steadiness), **C**onformidade (Conscientiousness).
    *   Conceito Central: Todos temos os 4 fatores em intensidades diferentes.
    *   Ícones simples representando cada fator.

4.  **Slide 4: Os Eixos do Comportamento**
    *   Visualização simplificada dos eixos:
        *   Percepção do Ambiente: Antagônico vs. Favorável
        *   Resposta ao Ambiente: Ativo vs. Passivo/Reativo
    *   Posicionamento de cada perfil nos quadrantes (D-Ativo/Antagônico, I-Ativo/Favorável, S-Passivo/Favorável, C-Passivo/Antagônico).

5.  **Slide 5: Perfil D - Dominância (Executor)**
    *   Foco: Como lida com **Problemas e Desafios**.
    *   Palavras-chave: Direto, Decidido, Competitivo, Focado em Resultados, Rápido, Assertivo.
    *   Motivadores Principais: Poder, Realização, Controle, Desafios.
    *   Comunicação Preferida: Direta, objetiva, focada em resultados.
    *   Imagem/Ícone: Alvo, Seta para cima, Leão.

6.  **Slide 6: Perfil I - Influência (Comunicador)**
    *   Foco: Como lida com **Pessoas e Influência**.
    *   Palavras-chave: Otimista, Sociável, Entusiasmado, Persuasivo, Comunicativo, Inspirador.
    *   Motivadores Principais: Reconhecimento Social, Aprovação, Relacionamentos.
    *   Comunicação Preferida: Amigável, entusiasta, informal, focada em pessoas.
    *   Imagem/Ícone: Pessoas conectadas, Balão de diálogo, Sol.

7.  **Slide 7: Perfil S - Estabilidade (Planejador)**
    *   Foco: Como lida com **Ritmo e Mudanças**.
    *   Palavras-chave: Paciente, Calmo, Leal, Consistente, Cooperador, Bom Ouvinte.
    *   Motivadores Principais: Segurança, Harmonia, Apreciação Sincera, Estabilidade.
    *   Comunicação Preferida: Calma, paciente, lógica, focada na segurança.
    *   Imagem/Ícone: Corrente/Elos, Coração, Árvore, Âncora.

8.  **Slide 8: Perfil C - Conformidade (Analista)**
    *   Foco: Como lida com **Regras e Procedimentos**.
    *   Palavras-chave: Preciso, Analítico, Cauteloso, Organizado, Detalhista, Lógico.
    *   Motivadores Principais: Precisão, Qualidade, Lógica, Padrões Claros.
    *   Comunicação Preferida: Factual, lógica, baseada em dados, detalhada.
    *   Imagem/Ícone: Engrenagem, Lupa, Check-list, Gráfico.

9.  **Slide 9: Resumo dos Perfis: Forças e Limitações**
    *   Tabela ou diagrama simples comparando:
        *   Perfil D: Força (Resultados), Limitação (Impaciência)
        *   Perfil I: Força (Comunicação), Limitação (Foco/Detalhes)
        *   Perfil S: Força (Cooperação), Limitação (Resistência à Mudança)
        *   Perfil C: Força (Qualidade), Limitação (Perfeccionismo/Lentidão)
    *   Mensagem Chave: Todos os perfis são valiosos e necessários.

10. **Slide 10: Indo Além: As Combinações DISC**
    *   Explicação: Raramente somos um perfil "puro". Combinações são comuns.
    *   Exemplos de combinações de 2 fatores (mencionar 2-3, ex: DI-Empreendedor, SC-Especialista, IS-Aconselhador).
    *   Exemplo de combinação de 3 fatores (mencionar 1, ex: ISC-Articulador).
    *   Mensagem: As combinações trazem riqueza e complexidade ao perfil.
    *   Visual: Gráfico com sobreposição das cores/círculos DISC.

11. **Slide 11: DISC no Dia a Dia: Aplicações Práticas**
    *   **Comunicação:** Adaptar a abordagem (D-Direto, I-Amigável, S-Paciente, C-Factual).
    *   **Trabalho em Equipe:** Valorizar a diversidade de perfis para complementar habilidades.
    *   **Liderança:** Adaptar o estilo de liderança às necessidades de cada perfil.
    *   **Resolução de Conflitos:** Entender as diferentes perspectivas e necessidades.
    *   Ícones representando cada aplicação.

12. **Slide 12: Dando Feedback que Funciona**
    *   Importância do feedback personalizado.
    *   Dicas rápidas para cada perfil:
        *   Feedback para D: Direto, focado em resultados, desafiador.
        *   Feedback para I: Positivo, encorajador, focado em relações.
        *   Feedback para S: Gentil, paciente, focado em segurança, explicar o "porquê".
        *   Feedback para C: Específico, lógico, baseado em fatos, focado em qualidade.
    *   Referência ao material completo para exemplos detalhados.

13. **Slide 13: Descobrindo seu Perfil (Tendências)**
    *   Apresentação do Questionário Simplificado (mencionar o arquivo HTML).
    *   Reforçar: Ferramenta de autoconhecimento, não diagnóstico.
    *   Instruções básicas: Marcar 2 palavras por grupo, honestidade.
    *   Breve menção sobre como interpretar (maior pontuação indica tendência).

14. **Slide 14: Próximos Passos**
    *   Incentivo à auto-observação e reflexão.
    *   Praticar a identificação (respeitosa) de tendências nos colegas.
    *   Usar o conhecimento para adaptar a comunicação e colaboração.
    *   Buscar aprofundamento (material completo, discussões).

15. **Slide 15: Conclusão e Perguntas**
    *   Recapitulação rápida: DISC como ferramenta para autoconhecimento e melhores relações.
    *   Mensagem final de valorização da diversidade comportamental.
    *   Agradecimento.
    *   Abertura para perguntas.

16. **Slide 16: Referências**
    *   Listar as fontes consultadas (PDF original, Solides, Gescon, Escola de Inspirações).

**Observações:**
*   Usar design limpo e profissional.
*   Utilizar imagens e ícones relevantes para ilustrar os conceitos.
*   Manter o texto dos slides conciso (tópicos e palavras-chave), usando o discurso para detalhar.
*   Garantir consistência visual em toda a apresentação.
