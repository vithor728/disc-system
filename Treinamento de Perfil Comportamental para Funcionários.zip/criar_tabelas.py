from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os
import sys
import logging

# Configurar logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Definir modelos para o banco de dados
db = SQLAlchemy()

class Equipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    descricao = db.Column(db.String(200))
    
    colaboradores = db.relationship('Colaborador', backref='equipe', lazy=True)
    usuarios = db.relationship('Usuario', backref='equipe', lazy=True)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='coordenador')
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=True)

class Colaborador(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    cargo = db.Column(db.String(100))
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=False)
    data_preenchimento = db.Column(db.DateTime)
    
    pontuacao_d = db.Column(db.Integer, default=0)
    pontuacao_i = db.Column(db.Integer, default=0)
    pontuacao_s = db.Column(db.Integer, default=0)
    pontuacao_c = db.Column(db.Integer, default=0)
    
    perfil_predominante = db.Column(db.String(1))
    perfil_secundario = db.Column(db.String(1))

# Criar aplicação Flask para inicialização do banco
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

def criar_tabelas():
    """Cria todas as tabelas no banco de dados"""
    with app.app_context():
        try:
            db.create_all()
            logger.info("Tabelas criadas com sucesso!")
            
            # Verificar tabelas criadas
            tabelas = db.engine.table_names()
            logger.info(f"Tabelas no banco: {tabelas}")
            
            return True
        except Exception as e:
            logger.error(f"Erro ao criar tabelas: {e}")
            return False

if __name__ == "__main__":
    print("\n=== CRIANDO TABELAS NO BANCO DE DADOS ===")
    criar_tabelas()
