from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import datetime

db = SQLAlchemy()

class Equipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    descricao = db.Column(db.String(200))
    
    colaboradores = db.relationship('Colaborador', backref='equipe', lazy=True)
    usuarios = db.relationship('Usuario', backref='equipe_gerenciada', lazy=True)
    
    def __repr__(self):
        return f'<Equipe {self.nome}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'descricao': self.descricao
        }

class Colaborador(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    cargo = db.Column(db.String(100))
    data_preenchimento = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    pontuacao_d = db.Column(db.Integer, default=0)
    pontuacao_i = db.Column(db.Integer, default=0)
    pontuacao_s = db.Column(db.Integer, default=0)
    pontuacao_c = db.Column(db.Integer, default=0)
    perfil_predominante = db.Column(db.String(20))
    perfil_secundario = db.Column(db.String(20))
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=False)
    
    def __repr__(self):
        return f'<Colaborador {self.nome}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'cargo': self.cargo,
            'data_preenchimento': self.data_preenchimento.strftime('%d/%m/%Y %H:%M'),
            'pontuacao_d': self.pontuacao_d,
            'pontuacao_i': self.pontuacao_i,
            'pontuacao_s': self.pontuacao_s,
            'pontuacao_c': self.pontuacao_c,
            'perfil_predominante': self.perfil_predominante,
            'perfil_secundario': self.perfil_secundario,
            'equipe_id': self.equipe_id,
            'equipe_nome': self.equipe.nome if self.equipe else None
        }

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='coordenador')  # 'admin' ou 'coordenador'
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=True)  # NULL para admin (acesso a todas)
    
    def __repr__(self):
        return f'<Usuario {self.nome}>'
    
    def set_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)
    
    def verificar_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)
    
    def is_admin(self):
        return self.nivel_acesso == 'admin'
    
    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'nivel_acesso': self.nivel_acesso,
            'equipe_id': self.equipe_id,
            'equipe_nome': self.equipe.nome if self.equipe_id else 'Todas (Admin)'
        }
