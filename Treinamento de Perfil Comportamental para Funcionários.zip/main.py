from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, g
import os
import sys
import json
import datetime
import logging
from pathlib import Path
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('auth.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.models import db, Usuario, Equipe, Colaborador
from src.auth import init_auth, login_required, admin_required, pode_acessar_equipe, pode_acessar_colaborador
from src.auth import criar_usuario_admin_inicial, criar_equipes_iniciais, criar_coordenadores_iniciais

app = Flask(__name__)
app.secret_key = 'disc_app_secret_key'

# Configuração do banco de dados SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar o banco de dados
db.init_app(app)

# Inicializar autenticação
init_auth(app, db)

# Criar tabelas e dados iniciais
with app.app_context():
    db.create_all()
    criar_usuario_admin_inicial(db)
    criar_equipes_iniciais(db)
    criar_coordenadores_iniciais(db)
    logger.info("Banco de dados inicializado")

# Rotas
@app.route('/')
def index():
    logger.debug("Acessando página inicial")
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        # Aceitar tanto email quanto nome de usuário
        identificador = request.form.get('identificador')
        senha = request.form.get('senha')
        
        logger.info(f"Tentativa de login com identificador: {identificador}")
        
        # Buscar usuário por email ou nome de usuário
        usuario = Usuario.query.filter(
            (Usuario.email == identificador) | (Usuario.nome == identificador)
        ).first()
        
        if not usuario:
            logger.warning(f"Usuário não encontrado: {identificador}")
            error = 'Credenciais inválidas. Por favor, tente novamente.'
        elif usuario.verificar_senha(senha):
            logger.info(f"Login bem-sucedido: {usuario.email}")
            session['usuario_id'] = usuario.id
            flash(f'Bem-vindo, {usuario.nome}!', 'success')
            return redirect(url_for('admin'))
        else:
            logger.warning(f"Senha incorreta para: {identificador}")
            error = 'Credenciais inválidas. Por favor, tente novamente.'
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    logger.debug("Realizando logout")
    session.pop('usuario_id', None)
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('index'))

@app.route('/questionario', methods=['GET', 'POST'])
def questionario():
    # Buscar todas as equipes para o formulário
    equipes = Equipe.query.all()
    
    if request.method == 'POST':
        # Processar dados do formulário
        nome = request.form.get('nome')
        email = request.form.get('email')
        cargo = request.form.get('cargo')
        equipe_id = request.form.get('equipe_id')
        
        # Validar equipe
        if not equipe_id:
            flash('Por favor, selecione uma equipe.', 'danger')
            return render_template('questionario.html', equipes=equipes)
        
        # Processar respostas do questionário
        respostas = {}
        for i in range(1, 11):  # 10 grupos de perguntas
            grupo_key = f'grupo{i}'
            respostas[grupo_key] = request.form.getlist(grupo_key)
        
        # Calcular pontuações DISC
        pontuacao_d = 0
        pontuacao_i = 0
        pontuacao_s = 0
        pontuacao_c = 0
        
        for grupo, valores in respostas.items():
            for valor in valores:
                if valor == 'D':
                    pontuacao_d += 1
                elif valor == 'I':
                    pontuacao_i += 1
                elif valor == 'S':
                    pontuacao_s += 1
                elif valor == 'C':
                    pontuacao_c += 1
        
        # Determinar perfil predominante e secundário
        pontuacoes = {
            'D': pontuacao_d,
            'I': pontuacao_i,
            'S': pontuacao_s,
            'C': pontuacao_c
        }
        
        perfil_predominante = max(pontuacoes, key=pontuacoes.get)
        
        # Remover o perfil predominante para encontrar o secundário
        pontuacoes_sem_predominante = pontuacoes.copy()
        pontuacoes_sem_predominante.pop(perfil_predominante)
        perfil_secundario = max(pontuacoes_sem_predominante, key=pontuacoes_sem_predominante.get)
        
        # Verificar se já existe um colaborador com este email
        colaborador = Colaborador.query.filter_by(email=email).first()
        
        if colaborador:
            # Atualizar colaborador existente
            colaborador.nome = nome
            colaborador.cargo = cargo
            colaborador.equipe_id = equipe_id
            colaborador.data_preenchimento = datetime.datetime.utcnow()
            colaborador.pontuacao_d = pontuacao_d
            colaborador.pontuacao_i = pontuacao_i
            colaborador.pontuacao_s = pontuacao_s
            colaborador.pontuacao_c = pontuacao_c
            colaborador.perfil_predominante = perfil_predominante
            colaborador.perfil_secundario = perfil_secundario
        else:
            # Criar novo colaborador
            colaborador = Colaborador(
                nome=nome,
                email=email,
                cargo=cargo,
                equipe_id=equipe_id,
                pontuacao_d=pontuacao_d,
                pontuacao_i=pontuacao_i,
                pontuacao_s=pontuacao_s,
                pontuacao_c=pontuacao_c,
                perfil_predominante=perfil_predominante,
                perfil_secundario=perfil_secundario
            )
            db.session.add(colaborador)
        
        db.session.commit()
        
        # Redirecionar para a página de resultados
        return redirect(url_for('resultado', id=colaborador.id))
    
    return render_template('questionario.html', equipes=equipes)

@app.route('/resultado/<int:id>')
def resultado(id):
    colaborador = Colaborador.query.get_or_404(id)
    return render_template('resultado.html', colaborador=colaborador)

@app.route('/admin')
@login_required
def admin():
    logger.debug(f"Acessando painel admin por: {g.usuario.email}")
    # Se for admin, busca todas as equipes e colaboradores
    # Se for coordenador, busca apenas sua equipe e colaboradores
    if g.usuario.is_admin():
        equipes = Equipe.query.all()
        colaboradores = Colaborador.query.all()
        logger.debug(f"Usuário admin: carregando todas as equipes e colaboradores")
    else:
        equipes = [g.usuario.equipe] if g.usuario.equipe else []
        colaboradores = Colaborador.query.filter_by(equipe_id=g.usuario.equipe_id).all()
        logger.debug(f"Usuário coordenador: carregando equipe {g.usuario.equipe_id}")
    
    return render_template('admin.html', equipes=equipes, colaboradores=colaboradores)

@app.route('/relatorio/<int:id>')
@login_required
def relatorio(id):
    colaborador = Colaborador.query.get_or_404(id)
    
    # Verificar se o usuário tem permissão para acessar este colaborador
    if not pode_acessar_colaborador(colaborador):
        flash('Você não tem permissão para acessar este colaborador.', 'danger')
        return redirect(url_for('admin'))
    
    return render_template('relatorio.html', colaborador=colaborador)

@app.route('/gerenciar_usuarios')
@admin_required
def gerenciar_usuarios():
    usuarios = Usuario.query.all()
    equipes = Equipe.query.all()
    mensagem = request.args.get('mensagem')
    tipo_mensagem = request.args.get('tipo_mensagem', 'info')
    
    return render_template('gerenciar_usuarios.html', 
                          usuarios=usuarios, 
                          equipes=equipes, 
                          mensagem=mensagem, 
                          tipo_mensagem=tipo_mensagem)

@app.route('/criar_usuario', methods=['POST'])
@admin_required
def criar_usuario():
    nome = request.form.get('nome')
    email = request.form.get('email')
    senha = request.form.get('senha')
    nivel_acesso = request.form.get('nivel_acesso')
    equipe_id = request.form.get('equipe_id') if request.form.get('equipe_id') else None
    
    # Validar dados
    if nivel_acesso == 'coordenador' and not equipe_id:
        flash('Coordenadores devem estar associados a uma equipe.', 'danger')
        return redirect(url_for('gerenciar_usuarios'))
    
    # Verificar se email já existe
    if Usuario.query.filter_by(email=email).first():
        flash('Este email já está em uso.', 'danger')
        return redirect(url_for('gerenciar_usuarios'))
    
    # Criar usuário
    usuario = Usuario(
        nome=nome,
        email=email,
        nivel_acesso=nivel_acesso,
        equipe_id=equipe_id
    )
    usuario.set_senha(senha)
    
    db.session.add(usuario)
    db.session.commit()
    
    flash(f'Usuário {nome} criado com sucesso!', 'success')
    return redirect(url_for('gerenciar_usuarios'))

@app.route('/atualizar_usuario', methods=['POST'])
@admin_required
def atualizar_usuario():
    id = request.form.get('id')
    nome = request.form.get('nome')
    email = request.form.get('email')
    nivel_acesso = request.form.get('nivel_acesso')
    equipe_id = request.form.get('equipe_id') if request.form.get('equipe_id') else None
    
    # Validar dados
    if nivel_acesso == 'coordenador' and not equipe_id:
        flash('Coordenadores devem estar associados a uma equipe.', 'danger')
        return redirect(url_for('gerenciar_usuarios'))
    
    # Buscar usuário
    usuario = Usuario.query.get_or_404(id)
    
    # Verificar se email já existe (exceto para o próprio usuário)
    email_existente = Usuario.query.filter_by(email=email).first()
    if email_existente and email_existente.id != int(id):
        flash('Este email já está em uso.', 'danger')
        return redirect(url_for('gerenciar_usuarios'))
    
    # Atualizar usuário
    usuario.nome = nome
    usuario.email = email
    usuario.nivel_acesso = nivel_acesso
    usuario.equipe_id = equipe_id
    
    db.session.commit()
    
    flash(f'Usuário {nome} atualizado com sucesso!', 'success')
    return redirect(url_for('gerenciar_usuarios'))

@app.route('/resetar_senha', methods=['POST'])
@admin_required
def resetar_senha():
    id = request.form.get('id')
    nova_senha = request.form.get('nova_senha')
    confirmar_senha = request.form.get('confirmar_senha')
    
    # Validar senhas
    if nova_senha != confirmar_senha:
        flash('As senhas não coincidem.', 'danger')
        return redirect(url_for('gerenciar_usuarios'))
    
    # Buscar usuário
    usuario = Usuario.query.get_or_404(id)
    
    # Resetar senha
    usuario.set_senha(nova_senha)
    db.session.commit()
    
    flash(f'Senha do usuário {usuario.nome} resetada com sucesso!', 'success')
    return redirect(url_for('gerenciar_usuarios'))

@app.route('/excluir_usuario', methods=['POST'])
@admin_required
def excluir_usuario():
    id = request.form.get('id')
    
    # Não permitir excluir o próprio usuário
    if int(id) == g.usuario.id:
        flash('Você não pode excluir seu próprio usuário.', 'danger')
        return redirect(url_for('gerenciar_usuarios'))
    
    # Buscar usuário
    usuario = Usuario.query.get_or_404(id)
    
    # Excluir usuário
    db.session.delete(usuario)
    db.session.commit()
    
    flash(f'Usuário {usuario.nome} excluído com sucesso!', 'success')
    return redirect(url_for('gerenciar_usuarios'))

@app.route('/gerenciar_equipes')
@admin_required
def gerenciar_equipes():
    equipes = Equipe.query.all()
    mensagem = request.args.get('mensagem')
    tipo_mensagem = request.args.get('tipo_mensagem', 'info')
    
    return render_template('gerenciar_equipes.html', 
                          equipes=equipes, 
                          mensagem=mensagem, 
                          tipo_mensagem=tipo_mensagem)

@app.route('/criar_equipe', methods=['POST'])
@admin_required
def criar_equipe():
    nome = request.form.get('nome')
    descricao = request.form.get('descricao')
    
    # Verificar se nome já existe
    if Equipe.query.filter_by(nome=nome).first():
        flash('Já existe uma equipe com este nome.', 'danger')
        return redirect(url_for('gerenciar_equipes'))
    
    # Criar equipe
    equipe = Equipe(
        nome=nome,
        descricao=descricao
    )
    
    db.session.add(equipe)
    db.session.commit()
    
    flash(f'Equipe {nome} criada com sucesso!', 'success')
    return redirect(url_for('gerenciar_equipes'))

@app.route('/atualizar_equipe', methods=['POST'])
@admin_required
def atualizar_equipe():
    id = request.form.get('id')
    nome = request.form.get('nome')
    descricao = request.form.get('descricao')
    
    # Buscar equipe
    equipe = Equipe.query.get_or_404(id)
    
    # Verificar se nome já existe (exceto para a própria equipe)
    nome_existente = Equipe.query.filter_by(nome=nome).first()
    if nome_existente and nome_existente.id != int(id):
        flash('Já existe uma equipe com este nome.', 'danger')
        return redirect(url_for('gerenciar_equipes'))
    
    # Atualizar equipe
    equipe.nome = nome
    equipe.descricao = descricao
    
    db.session.commit()
    
    flash(f'Equipe {nome} atualizada com sucesso!', 'success')
    return redirect(url_for('gerenciar_equipes'))

@app.route('/excluir_equipe', methods=['POST'])
@admin_required
def excluir_equipe():
    id = request.form.get('id')
    
    # Buscar equipe
    equipe = Equipe.query.get_or_404(id)
    
    # Verificar se há colaboradores associados
    colaboradores = Colaborador.query.filter_by(equipe_id=id).all()
    for colaborador in colaboradores:
        db.session.delete(colaborador)
    
    # Verificar se há usuários associados
    usuarios = Usuario.query.filter_by(equipe_id=id).all()
    for usuario in usuarios:
        usuario.equipe_id = None
    
    # Excluir equipe
    db.session.delete(equipe)
    db.session.commit()
    
    flash(f'Equipe {equipe.nome} excluída com sucesso!', 'success')
    return redirect(url_for('gerenciar_equipes'))

@app.route('/api/estatisticas')
@login_required
def api_estatisticas():
    equipe_id = request.args.get('equipe_id')
    
    # Verificar permissões
    if equipe_id and not pode_acessar_equipe(int(equipe_id)):
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Filtrar colaboradores por equipe se especificado
    if equipe_id:
        colaboradores = Colaborador.query.filter_by(equipe_id=equipe_id).all()
    elif g.usuario.is_admin():
        colaboradores = Colaborador.query.all()
    else:
        colaboradores = Colaborador.query.filter_by(equipe_id=g.usuario.equipe_id).all()
    
    total = len(colaboradores)
    
    if total == 0:
        return jsonify({
            'total': 0,
            'contagem': {
                'D': 0,
                'I': 0,
                'S': 0,
                'C': 0
            },
            'percentuais': {
                'D': 0,
                'I': 0,
                'S': 0,
                'C': 0
            }
        })
    
    contagem_perfis = {
        'D': 0,
        'I': 0,
        'S': 0,
        'C': 0
    }
    
    for c in colaboradores:
        contagem_perfis[c.perfil_predominante] += 1
    
    percentuais = {
        perfil: (contagem / total) * 100 
        for perfil, contagem in contagem_perfis.items()
    }
    
    return jsonify({
        'total': total,
        'contagem': contagem_perfis,
        'percentuais': percentuais
    })

@app.route('/api/colaboradores')
@login_required
def api_colaboradores():
    equipe_id = request.args.get('equipe_id')
    
    # Verificar permissões
    if equipe_id and not pode_acessar_equipe(int(equipe_id)):
        return jsonify({'error': 'Acesso negado'}), 403
    
    # Filtrar colaboradores por equipe se especificado
    if equipe_id:
        colaboradores = Colaborador.query.filter_by(equipe_id=equipe_id).all()
    elif g.usuario.is_admin():
        colaboradores = Colaborador.query.all()
    else:
        colaboradores = Colaborador.query.filter_by(equipe_id=g.usuario.equipe_id).all()
    
    return jsonify([c.to_dict() for c in colaboradores])

# Rota de diagnóstico
@app.route('/diagnostico')
def diagnostico():
    try:
        # Verificar tabelas
        tabelas = db.engine.table_names()
        logger.info(f"Tabelas no banco: {tabelas}")
        
        # Verificar usuários
        usuarios = Usuario.query.all()
        logger.info(f"Total de usuários: {len(usuarios)}")
        for u in usuarios:
            logger.info(f"Usuário: {u.email}, Nível: {u.nivel_acesso}")
        
        # Verificar equipes
        equipes = Equipe.query.all()
        logger.info(f"Total de equipes: {len(equipes)}")
        for e in equipes:
            logger.info(f"Equipe: {e.nome}")
        
        return jsonify({
            'status': 'success',
            'tabelas': tabelas,
            'usuarios': [{'id': u.id, 'nome': u.nome, 'email': u.email, 'nivel': u.nivel_acesso} for u in usuarios],
            'equipes': [{'id': e.id, 'nome': e.nome} for e in equipes]
        })
    except Exception as e:
        logger.error(f"Erro ao diagnosticar banco: {e}")
        return jsonify({'status': 'error', 'mensagem': str(e)})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
