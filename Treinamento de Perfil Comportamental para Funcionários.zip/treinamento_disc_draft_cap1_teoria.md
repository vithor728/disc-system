## Capítulo 1: A Metodologia DISC - Entendendo os Estilos Comportamentais

### Origens e Fundamentos

A busca por compreender e categorizar o comportamento humano não é recente. Desde a antiguidade, filósofos e estudiosos tentam decifrar os padrões que regem nossas ações e interações. Contudo, foi no século XX que um marco significativo surgiu com o trabalho do Dr. William Moulton Marston. Em 1928, este advogado e Doutor em Psicologia pela Universidade de Harvard publicou sua obra seminal "As Emoções das Pessoas Normais". Nela, Marston consolidou e sistematizou conhecimentos prévios, apresentando um método inovador para entender os padrões de comportamento, temperamento e personalidade, focando nas respostas emocionais das pessoas em seu ambiente.

Marston não buscava diagnosticar patologias, mas sim compreender as reações comportamentais de indivíduos considerados "normais" em suas vidas cotidianas. Ele observou que as pessoas tendem a perceber o ambiente de duas formas principais: como favorável ou antagônico. Além disso, notou que a resposta a essa percepção também se manifesta de duas maneiras: agindo ativamente sobre o ambiente ou sendo mais passivo e adaptativo. A combinação dessas percepções e respostas deu origem à base da teoria DISC.

### Os Quatro Fatores Essenciais: D, I, S, C

A teoria DISC, cujo acrônimo deriva dos quatro fatores comportamentais identificados por Marston, postula que todos nós possuímos esses quatro estilos em diferentes intensidades, formando um perfil comportamental único. O comportamento, segundo Marston, é a soma das respostas de um indivíduo aos estímulos externos, moldada pela predominância e combinação desses fatores. Vamos conhecer cada um deles:

*   **D - Dominância (Dominance):** Refere-se a como a pessoa lida com problemas e desafios. Indivíduos com alta Dominância tendem a ser diretos, assertivos, focados em resultados, competitivos e rápidos na tomada de decisão. Eles percebem o ambiente como antagônico e agem ativamente sobre ele para superá-lo e alcançar seus objetivos. São motivados por poder, autoridade e controle.

*   **I - Influência (Influence):** Descreve como a pessoa lida com pessoas e as influencia. Pessoas com alta Influência são geralmente comunicativas, extrovertidas, otimistas, persuasivas e sociáveis. Elas percebem o ambiente como favorável e buscam interagir ativamente com ele, conectando-se com os outros e buscando reconhecimento social. São motivadas por relacionamentos, aprovação e liberdade de expressão.

*   **S - Estabilidade (Steadiness):** Relaciona-se a como a pessoa lida com o ritmo das coisas e mudanças. Indivíduos com alta Estabilidade são tipicamente pacientes, calmos, leais, bons ouvintes e preferem ambientes previsíveis e harmoniosos. Eles percebem o ambiente como favorável, mas tendem a ser mais passivos ou reativos, buscando segurança e cooperação. São motivados por segurança, estabilidade e apreciação sincera.

*   **C - Conformidade (Conscientiousness):** Indica como a pessoa lida com regras e procedimentos estabelecidos por outros. Pessoas com alta Conformidade são geralmente precisas, analíticas, detalhistas, organizadas e cautelosas. Elas percebem o ambiente como antagônico e respondem a ele de forma mais passiva ou adaptativa, focando em seguir normas, garantir a qualidade e evitar erros. São motivadas por precisão, lógica e padrões claros.

É crucial entender que não existe um perfil "melhor" ou "pior". Cada estilo tem suas próprias forças e potenciais limitações. A eficácia de um perfil depende do contexto e da situação. O autoconhecimento proporcionado pelo DISC permite que os indivíduos potencializem seus pontos fortes e desenvolvam estratégias para lidar com seus pontos de melhoria, além de facilitar a compreensão e a adaptação ao estilo dos outros, promovendo relacionamentos mais produtivos e harmoniosos.
