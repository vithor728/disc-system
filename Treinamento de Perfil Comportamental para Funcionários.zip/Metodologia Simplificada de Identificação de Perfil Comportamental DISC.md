# Metodologia Simplificada de Identificação de Perfil Comportamental DISC

## 1. Introdução

Esta metodologia foi desenvolvida como um complemento ao treinamento sobre Perfil Comportamental DISC. Seu objetivo é oferecer uma ferramenta prática e simplificada para que os colaboradores possam identificar suas tendências comportamentais predominantes no ambiente de trabalho, com base nos quatro fatores da metodologia DISC: Dominância (D), Influência (I), Estabilidade (S) e Conformidade (C).

É fundamental compreender que este é um instrumento de autoconhecimento e reflexão, e não um diagnóstico psicológico definitivo ou um rótulo. Os resultados indicam **tendências** comportamentais que podem ajudar a entender melhor a si mesmo e aos outros, facilitando a comunicação, a colaboração e o desenvolvimento pessoal e profissional.

Recomendamos fortemente a leitura e compreensão do material de treinamento completo sobre a Metodologia DISC antes de aplicar ou interpretar este questionário.

## 2. O Questionário de Autoavaliação

**Instruções:** Leia atentamente cada grupo de quatro palavras abaixo. Em cada grupo, marque as **DUAS (2)** palavras que você acredita que **MELHOR descrevem você** na maior parte do tempo, especialmente no seu **ambiente de trabalho**. Procure ser o mais honesto e espontâneo possível em suas escolhas.

**Grupos de Palavras:**

1.  [ ] Direto(a) 
    [ ] Otimista
    [ ] Paciente
    [ ] Preciso(a)

2.  [ ] Competitivo(a)
    [ ] Sociável
    [ ] Consistente
    [ ] Cauteloso(a)

3.  [ ] Decidido(a)
    [ ] Entusiasmado(a)
    [ ] Calmo(a)
    [ ] Analítico(a)

4.  [ ] Exigente
    [ ] Persuasivo(a)
    [ ] Leal
    [ ] Organizado(a)

5.  [ ] Audacioso(a)
    [ ] Inspirador(a)
    [ ] Metódico(a)
    [ ] Detalhista

6.  [ ] Assertivo(a)
    [ ] Comunicativo(a)
    [ ] Cooperador(a)
    [ ] Sistemático(a)

7.  [ ] Enérgico(a)
    [ ] Amigável
    [ ] Bom(a) Ouvinte
    [ ] Lógico(a)

8.  [ ] Focado(a) em Metas
    [ ] Expressivo(a)
    [ ] Previsível
    [ ] Cuidadoso(a)

9.  [ ] Independente
    [ ] Convincente
    [ ] Apoiador(a)
    [ ] Perfeccionista

10. [ ] Rápido(a)
    [ ] Divertido(a)
    [ ] Tranquilo(a)
    [ ] Disciplinado(a)

## 3. Como Aplicar

*   Distribua o questionário individualmente para cada colaborador.
*   Garanta um ambiente tranquilo e sem interrupções para o preenchimento.
*   Reforce as instruções: marcar **DUAS** palavras por grupo que melhor descrevam o comportamento no trabalho.
*   Tempo estimado: 5 a 10 minutos.
*   Assegure a confidencialidade das respostas individuais, a menos que o colaborador opte por compartilhar.

## 4. Como Pontuar

Após o preenchimento, some quantas vezes palavras associadas a cada fator (D, I, S, C) foram marcadas. Cada palavra no questionário corresponde a um fator específico:

*   **Palavra 1 de cada grupo:** Fator D (Dominância)
*   **Palavra 2 de cada grupo:** Fator I (Influência)
*   **Palavra 3 de cada grupo:** Fator S (Estabilidade)
*   **Palavra 4 de cada grupo:** Fator C (Conformidade)

**Exemplo de Contagem:**
Se no Grupo 1, a pessoa marcou "Direto(a)" e "Preciso(a)", ela pontua 1 para D e 1 para C.
Some os pontos para cada fator (D, I, S, C) em todos os 10 grupos. O total máximo de pontos por fator é 10, e o total geral de pontos (palavras marcadas) será sempre 20.

**Registre os Totais:**
*   Total D: ____
*   Total I: ____
*   Total S: ____
*   Total C: ____

## 5. Interpretando os Resultados

*   O(s) fator(es) com a(s) **maior(es) pontuação(ões)** indica(m) as tendências comportamentais predominantes do indivíduo.
*   É comum ter um ou dois fatores com pontuações mais altas, mas todos os quatro fatores estão presentes em algum grau.
*   **Consulte o material de treinamento DISC** para uma descrição detalhada das características, motivadores, medos, pontos fortes e pontos a desenvolver associados aos fatores predominantes.
*   **Foco no Desenvolvimento:** Utilize os resultados como ponto de partida para a reflexão sobre como potencializar os pontos fortes e desenvolver estratégias para lidar com os pontos de melhoria.
*   **Melhoria das Relações:** Incentive o uso do conhecimento sobre os próprios perfis e os dos colegas para adaptar a comunicação, melhorar a colaboração e construir relacionamentos mais eficazes.
*   **Discussão (Opcional):** Considere facilitar uma discussão em equipe (respeitando a confidencialidade individual) sobre a diversidade de perfis e como ela pode ser uma força para a equipe. Uma conversa individual de feedback também pode ser muito valiosa.

## 6. Limitações da Metodologia

É importante reconhecer que esta é uma ferramenta **simplificada**. Ela oferece um indicativo das tendências comportamentais, mas não possui a profundidade de análises mais complexas como as apresentadas no relatório original do CIS Assessment (ex: perfil natural vs. adaptado, intensidade exata, motivadores específicos, etc.).

Os resultados refletem a autopercepção do indivíduo no momento do preenchimento e podem variar ligeiramente dependendo do contexto ou estado emocional. Use os resultados como um guia para a autoconsciência e o diálogo, e não como uma classificação rígida.
