from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
import os
import sys

# Definir modelo simplificado para o usuário
db = SQLAlchemy()

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='admin')
    equipe_id = db.Column(db.Integer, nullable=True)

# Criar aplicação Flask
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Função para criar ou redefinir o usuário administrador
def reset_admin():
    with app.app_context():
        # Verificar se as tabelas existem
        try:
            # Tentar criar as tabelas se não existirem
            db.create_all()
            print("Tabelas criadas ou já existentes.")
        except Exception as e:
            print(f"Erro ao criar tabelas: {e}")
            return False

        try:
            # Buscar usuário admin existente
            admin = Usuario.query.filter_by(nivel_acesso='admin').first()
            
            if admin:
                print(f"Usuário administrador encontrado: {admin.email}")
                # Atualizar dados do admin existente
                admin.nome = "Victor Lima"
                admin.email = "victor.lima@gavresorts.com.br"
                admin.senha_hash = generate_password_hash("disc2025")
                print("Credenciais do administrador atualizadas.")
            else:
                # Criar novo usuário admin
                novo_admin = Usuario(
                    nome="Victor Lima",
                    email="victor.lima@gavresorts.com.br",
                    senha_hash=generate_password_hash("disc2025"),
                    nivel_acesso="admin"
                )
                db.session.add(novo_admin)
                print("Novo usuário administrador criado.")
            
            db.session.commit()
            print("Operação concluída com sucesso!")
            return True
        except Exception as e:
            print(f"Erro ao redefinir administrador: {e}")
            return False

if __name__ == "__main__":
    success = reset_admin()
    if success:
        print("\nCredenciais de acesso:")
        print("Email: victor.lima@gavresorts.com.br")
        print("Senha: disc2025")
    else:
        print("\nFalha ao redefinir credenciais.")
