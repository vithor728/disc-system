from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, g
import os
import sys
import json
import datetime
import logging
from pathlib import Path
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('auth_debug.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.auth_debug import db, Usuario, Equipe, Colaborador
from src.auth_debug import init_auth, login_required, admin_required, pode_acessar_equipe, pode_acessar_colaborador
from src.auth_debug import criar_usuario_admin_inicial, criar_equipes_iniciais, criar_coordenadores_iniciais
from src.auth_debug import diagnosticar_banco, testar_autenticacao

app = Flask(__name__)
app.secret_key = 'disc_app_secret_key_debug'

# Configuração do banco de dados SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app_debug.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar o banco de dados
db.init_app(app)

# Inicializar autenticação
init_auth(app, db)

# Criar tabelas e dados iniciais
with app.app_context():
    db.create_all()
    criar_usuario_admin_inicial(db)
    criar_equipes_iniciais(db)
    criar_coordenadores_iniciais(db)
    logger.info("Banco de dados inicializado")

# Rota de diagnóstico
@app.route('/diagnostico')
def diagnostico():
    resultado = diagnosticar_banco()
    return jsonify(resultado)

# Rota de teste de autenticação
@app.route('/teste_auth', methods=['GET', 'POST'])
def teste_auth():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        
        logger.info(f"Testando autenticação para: {email}")
        sucesso, mensagem = testar_autenticacao(email, senha)
        
        return render_template('teste_auth.html', 
                              resultado=True, 
                              sucesso=sucesso, 
                              mensagem=mensagem,
                              email=email)
    
    return render_template('teste_auth.html', resultado=False)

# Rotas
@app.route('/')
def index():
    logger.debug("Acessando página inicial")
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        
        logger.info(f"Tentativa de login: {email}")
        
        usuario = Usuario.query.filter_by(email=email).first()
        
        if not usuario:
            logger.warning(f"Usuário não encontrado: {email}")
            error = 'Credenciais inválidas. Por favor, tente novamente.'
        elif usuario.verificar_senha(senha):
            logger.info(f"Login bem-sucedido: {email}")
            session['usuario_id'] = usuario.id
            flash(f'Bem-vindo, {usuario.nome}!', 'success')
            return redirect(url_for('admin'))
        else:
            logger.warning(f"Senha incorreta para: {email}")
            error = 'Credenciais inválidas. Por favor, tente novamente.'
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    logger.debug("Realizando logout")
    session.pop('usuario_id', None)
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('index'))

@app.route('/admin')
@login_required
def admin():
    logger.debug(f"Acessando painel admin por: {g.usuario.email}")
    # Se for admin, busca todas as equipes e colaboradores
    # Se for coordenador, busca apenas sua equipe e colaboradores
    if g.usuario.is_admin():
        equipes = Equipe.query.all()
        colaboradores = Colaborador.query.all()
        logger.debug(f"Usuário admin: carregando todas as equipes e colaboradores")
    else:
        equipes = [g.usuario.equipe] if g.usuario.equipe else []
        colaboradores = Colaborador.query.filter_by(equipe_id=g.usuario.equipe_id).all()
        logger.debug(f"Usuário coordenador: carregando equipe {g.usuario.equipe_id}")
    
    return render_template('admin.html', equipes=equipes, colaboradores=colaboradores)

# Rota para criar usuário de teste
@app.route('/criar_usuario_teste')
def criar_usuario_teste():
    with app.app_context():
        # Verificar se já existe
        teste = Usuario.query.filter_by(email='teste@exemplo.com').first()
        if teste:
            return jsonify({'mensagem': 'Usuário de teste já existe', 'id': teste.id})
        
        # Criar usuário de teste
        novo_teste = Usuario(
            nome="Usuário de Teste",
            email="teste@exemplo.com",
            nivel_acesso="admin"
        )
        novo_teste.set_senha("teste123")
        db.session.add(novo_teste)
        db.session.commit()
        
        return jsonify({
            'mensagem': 'Usuário de teste criado com sucesso',
            'id': novo_teste.id,
            'email': novo_teste.email,
            'senha': 'teste123'
        })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
