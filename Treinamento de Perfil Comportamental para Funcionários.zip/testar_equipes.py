from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, g
import os
import sys
import json
import datetime
import logging
from pathlib import Path
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('equipes_debug.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.auth_debug import db, Usuario, Equipe, Colaborador
from src.auth_debug import init_auth, login_required, admin_required, pode_acessar_equipe, pode_acessar_colaborador

app = Flask(__name__)
app.secret_key = 'disc_app_secret_key_debug'

# Configuração do banco de dados SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar o banco de dados
db.init_app(app)

# Inicializar autenticação
init_auth(app, db)

# Rota para testar acesso por equipe
@app.route('/teste_equipes')
def teste_equipes():
    resultados = []
    
    with app.app_context():
        # Buscar todos os usuários
        usuarios = Usuario.query.all()
        equipes = Equipe.query.all()
        
        # Para cada usuário, testar acesso a cada equipe
        for usuario in usuarios:
            # Simular login do usuário
            g.usuario = usuario
            
            acesso_equipes = []
            for equipe in equipes:
                pode_acessar = pode_acessar_equipe(equipe.id)
                acesso_equipes.append({
                    'equipe_id': equipe.id,
                    'equipe_nome': equipe.nome,
                    'pode_acessar': pode_acessar
                })
            
            resultados.append({
                'usuario_id': usuario.id,
                'usuario_nome': usuario.nome,
                'usuario_email': usuario.email,
                'nivel_acesso': usuario.nivel_acesso,
                'equipe_id': usuario.equipe_id,
                'acesso_equipes': acesso_equipes
            })
    
    return jsonify(resultados)

# Rota para testar acesso a colaboradores
@app.route('/teste_colaboradores')
def teste_colaboradores():
    resultados = []
    
    with app.app_context():
        # Criar alguns colaboradores de teste se não existirem
        if Colaborador.query.count() == 0:
            for equipe in Equipe.query.all():
                colaborador = Colaborador(
                    nome=f"Colaborador Teste {equipe.nome}",
                    email=f"colaborador_{equipe.id}@exemplo.com",
                    cargo="Cargo Teste",
                    equipe_id=equipe.id,
                    pontuacao_d=5,
                    pontuacao_i=3,
                    pontuacao_s=2,
                    pontuacao_c=1,
                    perfil_predominante="D",
                    perfil_secundario="I"
                )
                db.session.add(colaborador)
            db.session.commit()
            logger.info("Colaboradores de teste criados")
        
        # Buscar todos os usuários e colaboradores
        usuarios = Usuario.query.all()
        colaboradores = Colaborador.query.all()
        
        # Para cada usuário, testar acesso a cada colaborador
        for usuario in usuarios:
            # Simular login do usuário
            g.usuario = usuario
            
            acesso_colaboradores = []
            for colaborador in colaboradores:
                pode_acessar = pode_acessar_colaborador(colaborador)
                acesso_colaboradores.append({
                    'colaborador_id': colaborador.id,
                    'colaborador_nome': colaborador.nome,
                    'colaborador_equipe_id': colaborador.equipe_id,
                    'pode_acessar': pode_acessar
                })
            
            resultados.append({
                'usuario_id': usuario.id,
                'usuario_nome': usuario.nome,
                'usuario_email': usuario.email,
                'nivel_acesso': usuario.nivel_acesso,
                'equipe_id': usuario.equipe_id,
                'acesso_colaboradores': acesso_colaboradores
            })
    
    return jsonify(resultados)

if __name__ == '__main__':
    # Executar teste de equipes
    with app.test_client() as client:
        print("\n=== TESTE DE ACESSO POR EQUIPE ===")
        response = client.get('/teste_equipes')
        resultados_equipes = json.loads(response.data)
        
        for resultado in resultados_equipes:
            print(f"Usuário: {resultado['usuario_nome']} ({resultado['usuario_email']})")
            print(f"Nível de acesso: {resultado['nivel_acesso']}")
            print(f"Equipe ID: {resultado['equipe_id']}")
            print("Acesso às equipes:")
            
            for acesso in resultado['acesso_equipes']:
                print(f"  - Equipe {acesso['equipe_nome']} (ID: {acesso['equipe_id']}): {'SIM' if acesso['pode_acessar'] else 'NÃO'}")
            
            print()
        
        print("\n=== TESTE DE ACESSO A COLABORADORES ===")
        response = client.get('/teste_colaboradores')
        resultados_colaboradores = json.loads(response.data)
        
        for resultado in resultados_colaboradores:
            print(f"Usuário: {resultado['usuario_nome']} ({resultado['usuario_email']})")
            print(f"Nível de acesso: {resultado['nivel_acesso']}")
            print(f"Equipe ID: {resultado['equipe_id']}")
            print("Acesso aos colaboradores:")
            
            for acesso in resultado['acesso_colaboradores']:
                print(f"  - Colaborador ID {acesso['colaborador_id']} (Equipe ID: {acesso['colaborador_equipe_id']}): {'SIM' if acesso['pode_acessar'] else 'NÃO'}")
            
            print()
