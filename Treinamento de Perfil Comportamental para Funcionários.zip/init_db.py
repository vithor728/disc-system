from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
import os

# Configuração inicial para garantir que o administrador seja criado corretamente
ADMIN_EMAIL = "victor.lima@gavresorts.com.br"
ADMIN_NOME = "Victor Lima"
ADMIN_SENHA = "disc2025"

# Definir modelo simplificado para inicialização
db = SQLAlchemy()

class Equipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False, unique=True)
    descricao = db.Column(db.String(200))

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False, unique=True)
    senha_hash = db.Column(db.String(200), nullable=False)
    nivel_acesso = db.Column(db.String(20), nullable=False, default='coordenador')
    equipe_id = db.Column(db.Integer, db.ForeignKey('equipe.id'), nullable=True)

def init_db():
    """Inicializa o banco de dados com dados essenciais"""
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///disc_app.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    
    with app.app_context():
        # Criar tabelas
        db.create_all()
        
        # Criar equipes iniciais
        equipes = [
            {'nome': 'Captação Dia', 'descricao': 'Equipe de captação - turno diurno'},
            {'nome': 'Captação Noite', 'descricao': 'Equipe de captação - turno noturno'},
            {'nome': 'Consultoria Dia', 'descricao': 'Equipe de consultoria - turno diurno'},
            {'nome': 'Consultoria Noite', 'descricao': 'Equipe de consultoria - turno noturno'},
            {'nome': 'Administrativa', 'descricao': 'Equipe administrativa'}
        ]
        
        for e in equipes:
            if not Equipe.query.filter_by(nome=e['nome']).first():
                equipe = Equipe(nome=e['nome'], descricao=e['descricao'])
                db.session.add(equipe)
        
        db.session.commit()
        
        # Criar usuário administrador
        admin = Usuario.query.filter_by(email=ADMIN_EMAIL).first()
        if not admin:
            admin = Usuario(
                nome=ADMIN_NOME,
                email=ADMIN_EMAIL,
                senha_hash=generate_password_hash(ADMIN_SENHA),
                nivel_acesso='admin'
            )
            db.session.add(admin)
            print(f"Administrador criado: {ADMIN_EMAIL}")
        else:
            admin.senha_hash = generate_password_hash(ADMIN_SENHA)
            print(f"Senha do administrador atualizada: {ADMIN_EMAIL}")
        
        # Criar coordenadores iniciais
        coordenadores = [
            {
                'nome': 'Gerente de Captação',
                'email': 'captacao@exemplo.com',
                'senha': 'captacao2025',
                'equipe_nome': 'Captação Dia'
            },
            {
                'nome': 'Supervisora de Consultoria',
                'email': 'consultoria@exemplo.com',
                'senha': 'consultoria2025',
                'equipe_nome': 'Consultoria Dia'
            },
            {
                'nome': 'Supervisor Administrativo',
                'email': 'administrativo@exemplo.com',
                'senha': 'admin2025',
                'equipe_nome': 'Administrativa'
            }
        ]
        
        for c in coordenadores:
            if not Usuario.query.filter_by(email=c['email']).first():
                equipe = Equipe.query.filter_by(nome=c['equipe_nome']).first()
                if equipe:
                    coordenador = Usuario(
                        nome=c['nome'],
                        email=c['email'],
                        senha_hash=generate_password_hash(c['senha']),
                        nivel_acesso='coordenador',
                        equipe_id=equipe.id
                    )
                    db.session.add(coordenador)
                    print(f"Coordenador criado: {c['email']}")
        
        db.session.commit()
        print("Inicialização do banco de dados concluída com sucesso!")

if __name__ == "__main__":
    init_db()
    print(f"\nCredenciais do administrador:")
    print(f"Email: {ADMIN_EMAIL}")
    print(f"Senha: {ADMIN_SENHA}")
