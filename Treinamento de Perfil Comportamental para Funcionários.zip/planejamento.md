# Planejamento do Questionário DISC em Página Única

## Objetivo
Criar uma aplicação web em página única que permita:
1. Coletar respostas do questionário DISC com identificação do colaborador
2. Gerar relatório simplificado com perfil e orientações de gestão
3. Apresentar gráfico com percentual de cada perfil na equipe

## Estrutura de Dados

### Modelo de Colaborador
- Nome
- Email (identificador único)
- Departamento/Cargo (opcional)
- Data de preenchimento
- Pontuações DISC (D, I, S, C)
- Perfil predominante
- Perfil secundário (se aplicável)

### Fluxo da Aplicação
1. **Página Inicial**:
   - Formulário para identificação do colaborador
   - Instruções do questionário
   - Questionário DISC (10 grupos de afirmações)
   - Botão de envio

2. **Processamento**:
   - Cálculo das pontuações DISC
   - Determinação do perfil predominante e secundário
   - Armazenamento dos dados no banco

3. **Página de Resultados**:
   - Resultado individual para o colaborador
   - Descrição do perfil
   - Pontos fortes e desafios

4. **Painel do Gestor** (acesso protegido):
   - Lista de todos os colaboradores e seus perfis
   - Relatório individual por colaborador com orientações de gestão
   - Gráfico de distribuição dos perfis na equipe
   - Opção para exportar dados

## Interface do Usuário

### Página do Questionário
- Design limpo e intuitivo
- Formulário de identificação no topo
- Instruções claras
- Questionário com grupos de afirmações
- Validação em tempo real
- Botão de envio destacado

### Painel do Gestor
- Dashboard com estatísticas gerais
- Gráfico de pizza/barras mostrando distribuição dos perfis
- Tabela de colaboradores com filtros
- Opção para visualizar relatório individual
- Funcionalidade de exportação

## Tecnologias
- **Backend**: Flask (Python)
- **Frontend**: HTML, CSS, JavaScript
- **Banco de Dados**: SQLite (para simplicidade)
- **Visualização**: Chart.js para gráficos

## Segurança
- Proteção básica para o painel do gestor
- Validação de dados no servidor
- Sanitização de inputs

## Próximos Passos
1. Implementar modelos de dados e rotas
2. Desenvolver interface do questionário
3. Criar lógica de processamento e armazenamento
4. Implementar painel do gestor com relatórios e gráficos
5. Testar e validar a aplicação
6. Implantar em produção
